from tkinter import messagebox
from tkinter import *
import subprocess
import grp
import os


global adminpath
global adminPermissions
global Path_admin
global permission
 
##Function to open the file names
def browsefiles_ad():
        #swtchuser = os.system('sudo user1 user123')
        #uname = getpass.getuser()
        #uname = os.setuid(swtchuser)
        #browsers =  browsefiles_ad()
        filename = filedialog.askopenfilename(initialdir = "/", title ="Select a File",
                                          filetypes = (("Text files",
                                                        "*.txt*"),
                                                       ("all files",
                                                        "*.*")))
        #label_file_explorer.configure(text="File Opened: "+filename)
        #print(uname)
   

#def screen():
    
## Owner changes the permissions

def change():
    #permission_ad = StringVar()    
    #group =  grp.getgrnam('studentgroup')
    #print(group[2])]

    #os.system("sudo chown :studentgroup "+Path.get())#(Path.get(), -1, group[2])
      
    #os.system("sudo chmod "+permission.get()+" " + Path.get())

    #os.system("sudo ch :studentgroup "+Path.get())
    #con = permission.get()
    #process = subprocess.call(['sudo chmod ', con,' '+Path.get()])
    #os.chmod(Path.get(),int(con, base=8))
    #print(user)
    try:
       print(adminpath.get())
       print("sudo chown :studentgroup "+adminpath.get())
       print("sudo chmod "+adminPermissions.get()+" " + adminpath.get())
       output1 = subprocess.check_output("sudo chown :studentgroup "+adminpath.get(),shell=True)
       print (output1)
       output2 = subprocess.check_output("sudo chmod "+adminPermissions.get()+" " + adminpath.get(),shell=True)
       print (output2)
    except:
       messagebox.showerror("Error","Invalid Path Or Permission")
    
##Define global variables

def Admin():
    #global Username

    global permission_AD
    #loginscreen = Toplevel(screen)

##Professor access window
adminscreen = Tk()

adminscreen.title('VFMS file management system')

adminscreen.geometry("900x500")

adminscreen.config(background ="white")

label_file_explorer = Label(adminscreen,
                            text = "VFMS file management system",
                            width = 100, height = 4,
                            fg = "black")


adminscreen.title ("Welcome Professor")
adminscreen.geometry("900x350")

#Username_admin =StringVar()
Path_admin =StringVar()
permission =StringVar()

Label (adminscreen,text = "File Access Change").pack()
Label (adminscreen,text = "").pack()
Label (adminscreen,text = "").pack()
Button (adminscreen,text ="Broswe File Structure" , height ="2", width ="30", command = browsefiles_ad).pack()
Label (adminscreen,text = "").pack()

##    Label (loginscreen,text = "** Username").pack()
##    Entry (loginscreen,textvariable = Username).pack()
##    Label (loginscreen,text = "").pack()

Label (adminscreen,text = "**Enter Folder/FilePath").pack()
adminpath=Entry (adminscreen, textvariable = Path_admin)
adminpath.pack()
Label (adminscreen,text = "**Enter Permissions").pack()
adminPermissions = Entry (adminscreen, textvariable = permission)
adminPermissions.pack()
Label (adminscreen,text = "").pack()
Label (adminscreen,text = "").pack()
Button (adminscreen,text ="Change Permission" , height ="2", width ="30", command = change).pack()
Label (adminscreen,text = "").pack()
Button (adminscreen,text ="Cancel" , height ="2", width ="30", command =exit).pack()
adminscreen.mainloop()


