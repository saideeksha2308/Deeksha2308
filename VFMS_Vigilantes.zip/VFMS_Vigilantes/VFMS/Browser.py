from tkinter import *
from tkinter import filedialog
import getpass
import os
##import User_Login

##def loginfunc():
##    #loginfunc()
##    c= User_Login.login_verify()
##    ##print(c)
##    

global Path
global Path_def
def openFile():
    os.system("gedit "+Path_def.get())

def browsefiles():
        #swtchuser = os.system('sudo user1 user123')
        #uname = getpass.getuser()
        #uname = os.setuid(swtchuser)
        
        filename = filedialog.askopenfilename(initialdir = "/", title ="Select a File",
                                          filetypes = (("Text files",
                                                        "*.txt*"),
                                                       ("all files",
                                                        "*.*")))
        #label_file_explorer.configure(text="File Opened: "+filename+"-"+uname)
        #print(uname)
    

    
##if loginfunc() == "success":

window = Tk()

window.title('File Explorer')

window.geometry("900x500")

window.config(background ="white")

label_file_explorer = Label(window,
                            text = "VFMS file management system",
                            width = 100, height = 4,
                            fg = "black")

button_explore = Button(window,
                        text = "Browse Files",command = browsefiles)
button_exit = Button(window,
                     text = "Exit", command = exit)
Path = StringVar()
Label (window,text = "").grid(column =1, row =2)

Label (window,text = "**Enter Folder/FilePath").grid(column =1, row =3)
Label (window,text = "").grid(column =1, row =4)
    
Path_def=Entry (window, textvariable = Path)
Path_def.grid(column =1, row =5)

Label (window,text = "").grid(column =1, row =6)
Label (window,text = "").grid(column =1, row =7)
Button (window,text ="Open" , height ="2", width ="30", command = openFile).grid(column =1, row =8)
Label (window,text = "").grid(column =1, row =9)

label_file_explorer.grid(column =1, row =1)

button_explore.grid(column =1, row =10)

button_exit.grid(column =1, row =11)



window.mainloop ()
##else:
##    elsewindow = Tk()
##
##    elsewindow.title('VFMS file management system')
##    messagebox.showinfo("Access Denied","Un Authorized Access")
##    elsewindow.mainloop ()
##                                                        
                                                        
                                                        
                                                                                                                           
